import tkinter as tk
from tkinter import ttk, messagebox
from tinydb import TinyDB, Query
from PIL import Image, ImageTk
from unidecode import unidecode as ud
import json
import os


class GUI:

    def mostrarImagen(self):
        try:
            self.Mas_original = Image.open("img/Mas.png")
            self.Mas_escalada = self.Mas_original.resize((25, 25))
            self.Mas_tk = ImageTk.PhotoImage(self.Mas_escalada)
        except Exception as e:
            print("Error cargando imagen:", e)
            self.Mas_tk = None

    def buscar(self):
        query = ud(self.caja_busqueda.get().lower())
        resultado = [libro for libro in self.libros if
                     query in ud(libro['Titulo'].lower()) or query in ud(libro['Autor'].lower())]

        for item in self.treeview.get_children():
            self.treeview.delete(item)

        for libro in resultado:
            self.treeview.insert("", "end",
                                 values=(libro['Titulo'], libro['Autor'], libro['ISBN'], libro['Existencias']))

    def agregarVenta(self):
        venta_ventana = tk.Toplevel(self.root)
        venta_ventana.title("Registrar Venta")
        venta_ventana.geometry("900x550")

        carrito = []
        total_var = tk.StringVar(value="Total: $0.00")
        existencias_var = tk.StringVar(value="Existencias: -")
        precio_var = tk.StringVar(value="")

        # === Tabla de libros ===
        tk.Label(venta_ventana, text="Selecciona un libro:", font=("Arial", 12, "bold")).pack(pady=5)
        tree_libros = ttk.Treeview(venta_ventana, columns=("Titulo", "Autor", "ISBN", "Existencias", "Precio"), show="headings", height=6)
        for col in ("Titulo", "Autor", "ISBN", "Existencias", "Precio"):
            tree_libros.heading(col, text=col)
        tree_libros.pack(padx=10, pady=5, fill="x")

        for libro in self.libros:
            tree_libros.insert("", "end",
                               values=(libro['Titulo'], libro['Autor'], libro['ISBN'],
                                       libro['Existencias'], libro.get('Precio', 0.0)))

        def actualizarDatos(event=None):
            seleccion = tree_libros.selection()
            if seleccion:
                item = tree_libros.item(seleccion[0])
                existencias = item["values"][3]
                precio = item["values"][4]
                existencias_var.set(f"Existencias: {existencias}")
                precio_var.set(f"{precio:.2f}")
            else:
                existencias_var.set("Existencias: -")
                precio_var.set("")

        tree_libros.bind("<<TreeviewSelect>>", actualizarDatos)

        # === Entradas ===
        frame_campos = tk.Frame(venta_ventana)
        frame_campos.pack(pady=10)

        tk.Label(frame_campos, text="Cantidad:", font=("Arial", 12)).grid(row=0, column=0, padx=5, pady=5)
        caja_cantidad = tk.Entry(frame_campos, font=("Arial", 12))
        caja_cantidad.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frame_campos, text="Precio unitario:", font=("Arial", 12)).grid(row=0, column=2, padx=5, pady=5)
        caja_precio = tk.Entry(frame_campos, font=("Arial", 12), textvariable=precio_var, state="readonly")
        caja_precio.grid(row=0, column=3, padx=5, pady=5)

        tk.Label(frame_campos, textvariable=existencias_var, font=("Arial", 12, "italic")).grid(row=0, column=4, padx=10)

        # === Carrito ===
        tree_carrito = ttk.Treeview(venta_ventana, columns=("Titulo", "Cantidad", "Precio", "Total"), show="headings", height=6)
        for col in ("Titulo", "Cantidad", "Precio", "Total"):
            tree_carrito.heading(col, text=col)
        tree_carrito.pack(padx=10, pady=5, fill="x")

        lbl_total = tk.Label(venta_ventana, textvariable=total_var, font=("Arial", 14, "bold"))
        lbl_total.pack(anchor="w", padx=10)

        def agregarAlCarrito():
            seleccion = tree_libros.selection()
            if not seleccion:
                messagebox.showwarning("Advertencia", "Selecciona un libro desde la tabla.")
                return

            try:
                cantidad = int(caja_cantidad.get())
                if cantidad <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Error", "Cantidad debe ser un número positivo.")
                return

            datos = tree_libros.item(seleccion[0])["values"]
            titulo, existencias, precio = datos[0], datos[3], datos[4]

            if cantidad > existencias:
                messagebox.showerror("Error", f"No hay suficientes existencias para '{titulo}'.")
                return

            total_linea = cantidad * precio
            carrito.append({
                "Titulo": titulo,
                "Cantidad": cantidad,
                "Precio": precio,
                "Total": total_linea
            })

            tree_carrito.insert("", "end", values=(titulo, cantidad, f"{precio:.2f}", f"{total_linea:.2f}"))
            calcularTotal()

            caja_cantidad.delete(0, tk.END)
            tree_libros.selection_remove(tree_libros.selection())

            existencias_var.set("Existencias: -")
            precio_var.set("")

        def calcularTotal():
            total = sum(item["Total"] for item in carrito)
            total_var.set(f"Total: ${total:.2f}")

        def registrarVenta():
            if not carrito:
                messagebox.showwarning("Advertencia", "No hay libros en la venta.")
                return

            with open("ventas.json", "a") as archivo:
                for venta in carrito:
                    json.dump(venta, archivo)
                    archivo.write("\n")

            for item in carrito:
                for libro in self.libros:
                    if libro["Titulo"] == item["Titulo"]:
                        libro["Existencias"] -= item["Cantidad"]
                        self.tb_libros.update({"Existencias": libro["Existencias"]}, Query().Titulo == item["Titulo"])
                        break

            messagebox.showinfo("Venta registrada", "Venta completada correctamente.")
            venta_ventana.destroy()
            self.libros = self.tb_libros.all()
            self.buscar()

        frame_botones = tk.Frame(venta_ventana)
        frame_botones.pack(pady=10)

        tk.Button(frame_botones, text="Agregar a la venta", font=("Arial", 12), command=agregarAlCarrito).grid(row=0, column=0, padx=20)
        tk.Button(frame_botones, text="Registrar Venta", font=("Arial", 12), command=registrarVenta).grid(row=0, column=1, padx=20)

    def __init__(self):
        self.db = TinyDB("libros.json")
        self.tb_libros = self.db.table("libros")
        self.libros = self.tb_libros.all()

        self.root = tk.Tk()
        self.root.title("Gestión de Librería")
        self.root.geometry("1000x600")

        self.panel_busqueda = tk.Frame(self.root, bg="#000000", height=70, width=1000)
        self.panel_busqueda.grid(row=0, column=0, sticky="ew")
        self.panel_busqueda.grid_propagate(False)

        self.panel_opciones = tk.Frame(self.root, bg="#810000", height=530, width=1000)
        self.panel_opciones.grid(row=1, column=0, sticky="nsew")
        self.panel_opciones.grid_propagate(False)

        self.caja_busqueda = tk.Entry(self.panel_busqueda, width=40, font=("Arial", 12))
        self.caja_busqueda.pack(side="left", padx=20, ipady=5)

        self.boton_busqueda = tk.Button(self.panel_busqueda, text="🔍", font=("Arial", 12),
                                        command=self.buscar)
        self.boton_busqueda.pack(side="left", padx=10)

        self.treeview = ttk.Treeview(self.panel_opciones, columns=("Titulo", "Autor", "ISBN", "Existencias"),
                                     show="headings", height=15)
        self.treeview.heading("Titulo", text="Título")
        self.treeview.heading("Autor", text="Autor")
        self.treeview.heading("ISBN", text="ISBN")
        self.treeview.heading("Existencias", text="Existencias")
        self.treeview.grid(row=0, column=0, columnspan=2, padx=20, pady=10)

        self.mostrarImagen()

        self.frame_boton_imagen = tk.Frame(self.panel_opciones, bg="#ffffff")
        self.frame_boton_imagen.grid(row=1, column=0, columnspan=2, pady=(20, 0), sticky="ew")

        if self.Mas_tk:
            self.botonMas = tk.Button(self.frame_boton_imagen, image=self.Mas_tk,
                                      command=self.agregarVenta, height=40, width=40)
            self.botonMas.pack(side="left", padx=(80, 5))
        else:
            self.botonMas = tk.Button(self.frame_boton_imagen, text="+", command=self.agregarVenta,
                                      height=2, width=5)
            self.botonMas.pack(side="left", padx=(80, 5))

        self.root.mainloop()


if __name__ == "__main__":
    gui = GUI()
